package com.example.gamelivebooster

import android.app.Activity
import android.content.Context
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.widget.*
import java.io.BufferedReader
import java.io.FileReader

class MainActivity : Activity() {
    private val handler = Handler(Looper.getMainLooper())
    private lateinit var ramText: TextView
    private lateinit var cpuText: TextView
    private lateinit var netText: TextView
    private lateinit var modeText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildUi()
        startMonitor()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 28, 28, 28)
            setBackgroundColor(0xFF0B0F19.toInt())
        }

        fun title(t: String, size: Float = 24f) = TextView(this).apply {
            text = t; textSize = size; setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 10, 0, 10)
        }
        fun card(t: String): TextView = title(t, 16f).apply {
            setTextColor(0xFFE6EAF2.toInt())
            setBackgroundColor(0xFF151B29.toInt())
            setPadding(20, 20, 20, 20)
        }

        root.addView(title("🎮 Game Live Booster"))
        root.addView(title("Optimasi aman untuk main game sambil live.", 14f))

        modeText = card("Mode: BALANCED")
        root.addView(modeText)

        val modes = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("SMOOTH", "BALANCED", "PERFORMANCE").forEach { mode ->
            val b = Button(this).apply {
                text = mode
                setOnClickListener { modeText.text = "Mode: $mode" }
            }
            modes.addView(b, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(modes)

        ramText = card("RAM: membaca...")
        cpuText = card("CPU: membaca...")
        netText = card("Network: membaca...")
        root.addView(ramText)
        root.addView(cpuText)
        root.addView(netText)

        val boost = Button(this).apply {
            text = "⚡ QUICK BOOST"
            setOnClickListener {
                Toast.makeText(this@MainActivity,
                    "Mode boost aktif. Android akan tetap mengelola proses sistem yang diperlukan.",
                    Toast.LENGTH_LONG).show()
            }
        }
        root.addView(boost)

        val dnd = Button(this).apply {
            text = "🔕 Buka pengaturan Jangan Ganggu"
            setOnClickListener {
                startActivity(android.content.Intent(android.provider.Settings.ACTION_ZEN_MODE_SETTINGS))
            }
        }
        root.addView(dnd)

        val live = Button(this).apply {
            text = "📡 Buka aplikasi Live"
            setOnClickListener {
                val pm = packageManager
                val candidates = listOf(
                    "com.yy.leopard", "com.facebook.orca",
                    "com.google.android.youtube", "com.tiktok.lite"
                )
                val pkg = candidates.firstOrNull { pm.getLaunchIntentForPackage(it) != null }
                if (pkg != null) startActivity(pm.getLaunchIntentForPackage(pkg))
                else Toast.makeText(this, "Aplikasi live belum ditemukan.", Toast.LENGTH_SHORT).show()
            }
        }
        root.addView(live)

        setContentView(root)
    }

    private fun startMonitor() {
        handler.post(object : Runnable {
            override fun run() {
                val mi = android.app.ActivityManager.MemoryInfo()
                (getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager)
                    .getMemoryInfo(mi)
                val used = mi.totalMem - mi.availMem
                ramText.text = "RAM: ${used / 1048576} MB / ${mi.totalMem / 1048576} MB"

                cpuText.text = "CPU: ${readCpu()}%"
                netText.text = "Network: ${networkType()}"
                handler.postDelayed(this, 1500)
            }
        })
    }

    private fun readCpu(): String {
        return try {
            val line = BufferedReader(FileReader("/proc/stat")).readLine()
            val p = line.trim().split(Regex("\s+"))
            val idle = p[4].toLong()
            val total = p.drop(1).take(8).sumOf { it.toLong() }
            val prevIdle = getPreferences(0).getLong("idle", idle)
            val prevTotal = getPreferences(0).getLong("total", total)
            getPreferences(0).edit().putLong("idle", idle).putLong("total", total).apply()
            val usage = if (total == prevTotal) 0 else
                ((total - prevTotal - (idle - prevIdle)).toDouble() / (total - prevTotal) * 100).toInt()
            usage.coerceIn(0, 100).toString()
        } catch (_: Exception) { "N/A" }
    }

    private fun networkType(): String {
        val cm = getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
        val n = cm.activeNetwork ?: return "Offline"
        val c = cm.getNetworkCapabilities(n) ?: return "Unknown"
        return when {
            c.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi‑Fi"
            c.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Mobile Data"
            else -> "Connected"
        }
    }

    override fun onDestroy() {
        handler.removeCallbacksAndMessages(null)
        super.onDestroy()
    }
}
