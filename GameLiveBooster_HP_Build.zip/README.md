# Game Live Booster

Project Android Kotlin sederhana untuk membantu memantau kondisi HP saat bermain game sambil live.

Fitur:
- Mode Smooth / Balanced / Performance (preset UI)
- Monitor RAM
- Monitor CPU
- Status koneksi
- Tombol Quick Boost
- Shortcut Jangan Ganggu
- Shortcut aplikasi live yang terdeteksi

Catatan:
Aplikasi ini sengaja tidak melakukan klaim "menambah FPS" secara paksa. Android modern membatasi akses ke CPU/GPU dan proses aplikasi lain tanpa root/system privileges.

Buka folder ini di Android Studio, tunggu Gradle sync, lalu Run ke HP Android.
